import { Injectable } from '@angular/core';

@Injectable()
export class PeopleService {
  people = [];
}
