import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'demo-lazy',
  templateUrl: './lazy.component.html',
})
export class LazyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
