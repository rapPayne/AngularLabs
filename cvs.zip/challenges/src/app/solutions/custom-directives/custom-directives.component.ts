import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'demo-custom-directives',
  templateUrl: './custom-directives.component.html',
  styleUrls: ['./custom-directives.component.css']
})
export class CustomDirectivesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
