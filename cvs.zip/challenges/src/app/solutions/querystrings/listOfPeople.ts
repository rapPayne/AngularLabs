export const people = [
  { name: { first: "Meenaxi", last: "Masali" }, gender: "female", picture: { large: "https://media-exp2.licdn.com/media/AAEAAQAAAAAAAAwSAAAAJDZiODc0OTM2LWFkOWQtNGY3MS1iZmFjLTRkZmRmMjMxMTkxOQ.jpg" } },
  { name: { first: "Ameya", last: "Chitnis" }, gender: "male", picture: { large: "https://media-exp2.licdn.com/media/AAEAAQAAAAAAAAVyAAAAJGIzM2FkNmM2LTFlM2ItNDY1MS05ZThmLWVmNzg5MzA2YjVmNA.jpg" } },
  { name: { first: "Ting", last: "Li" }, gender: "female", picture: { large: "https://media-exp2.licdn.com/media/p/3/000/2b7/3b5/2b2c158.jpg" } },
  { name: { first: "Ephrem", last: "Shiferaw" }, gender: "male", picture: { large: "https://media-exp2.licdn.com/media/AAEAAQAAAAAAAAliAAAAJGEwZjM0YTBkLTQyYTktNGUzMy1hM2I3LTgwZjRiMGUyOWZiNg.jpg" } },
  { name: { first: "Chaitali", last: "Kayastha" }, gender: "female", picture: { large: "http://images.desimartini.com/media/uploads/2017-5/rs_765x1024-170614162539-765.priyanka-chopra-bronzer.jl.061417.jpg" } },
]; 