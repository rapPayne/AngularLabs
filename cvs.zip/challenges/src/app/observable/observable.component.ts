import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'demo-observable',
  templateUrl: './observable.component.html',
  styleUrls: ['./observable.component.css']
})
export class ObservableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}