import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'demo-ajax-people-list',
  templateUrl: './ajax-people-list.component.html',
  styleUrls: ['./ajax-people-list.component.css']
})
export class AjaxPeopleListComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
