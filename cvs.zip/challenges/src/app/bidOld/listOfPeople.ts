export const people = [
  { name: { first: "Darshil", last: "Shah" }, gender: "male", picture: { large: "https://media-exp2.licdn.com/media/AAEAAQAAAAAAAAPZAAAAJGJhYjViN2M4LWViZTAtNDBiYS1hZTIyLTc0MTRkNzcxZTVjOA.jpg" } },
  { name: { first: "Karies", last: "Carter" }, gender: "male", picture: { large: "https://media-exp2.licdn.com/media/p/3/000/054/0ed/0a7e425.jpg" } },
  { name: { first: "Vijay", last: "Somayajula" }, gender: "male", picture: { large: "https://media-exp2.licdn.com/media/AAIA_wDGAAAAAQAAAAAAAApKAAAAJGI1MWE1ZDM2LTMyZDctNGFkYS1iMTIxLWMwYTdmYzE3YTQ2OQ.jpg" } },
  { name: { first: "Ram", last: "Vonteru" }, gender: "male", picture: { large: "https://media-exp2.licdn.com/media/p/4/000/162/377/2d14361.jpg" } },
  { name: { first: "Samba", last: "Dondapati" }, gender: "male", picture: { large: "https://media-exp2.licdn.com/media/AAEAAQAAAAAAAAkwAAAAJDVlZmZkYzg0LTQ5YmEtNDNmOC1iN2U5LTBhNGM5MzliYWZkYQ.jpg" } },
];