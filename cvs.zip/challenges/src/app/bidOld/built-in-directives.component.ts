import { Component, OnInit } from '@angular/core';
import { people } from './listOfPeople';
import { Http } from '@angular/http';

@Component({
  selector: 'demo-built-in-directives',
  templateUrl: './built-in-directives.component.html',
  styles: [`
  .person-card { display: grid; grid-template-columns: 1fr 1fr; }
  .person-card > div { margin: 20px; }
  .form-control-feedback {
    transform-origin: center 40%;
    transform: scale(4);
  }
  `]
})
export class BuiltInDirectivesComponent implements OnInit {
  noImageImg = "http://www.clker.com/cliparts/B/u/S/l/W/l/no-photo-available-hi.png";
  people;
  person = {name:{}, picture:{}};
  showForm = false;
  constructor(private _http:Http) { }

  ngOnInit() {
    this.people = people;
    //Consume a people api
    const url = "https://randomuser.me/api/?results=5";
    this._http.get(url).toPromise().then(
      res => {
        this.people = res.json().results;
      }
    );
  }

  addPerson(person) {
    this.people.unshift(person);
  }

  deletePerson(person) {
    console.log("the event object", person);
    this.people = this.people.filter(pers => pers !== person);
  }
}