export const people = [
  { name: { first: "Ben", last: "Frazier" }, gender: "male", picture: { large: "https://images-na.ssl-images-amazon.com/images/M/MV5BMTI4MzIxMTk0Nl5BMl5BanBnXkFtZTcwOTU5NjA0Mg@@._V1_SY1000_CR0,0,666,1000_AL_.jpg" } },
  { name: { first: "Kim", last: "Duerkop" }, gender: "female", picture: { large: "https://images-na.ssl-images-amazon.com/images/M/MV5BMjIzOTA0OTQyN15BMl5BanBnXkFtZTcwMjE1OTIwMw@@._V1_.jpg" } },
  { name: { first: "Gazanfer", last: "Shaikh-Ali" }, gender: "male", picture: { large: "https://images-na.ssl-images-amazon.com/images/M/MV5BMjA1MjE2MTQ2MV5BMl5BanBnXkFtZTcwMjE5MDY0Nw@@._V1_UX214_CR0,0,214,317_AL_.jpg" } },
  { name: { first: "Murali", last: "Jalasutram" }, gender: "male", picture: { large: "https://images-na.ssl-images-amazon.com/images/M/MV5BMTM0NzYzNDgxMl5BMl5BanBnXkFtZTcwMDg2MTMyMw@@._V1_.jpg" } },
  { name: { first: "Saurabh", last: "Somayajula" }, gender: "male", picture: { large: "https://images-na.ssl-images-amazon.com/images/M/MV5BMjEyMTEyOTQ0MV5BMl5BanBnXkFtZTcwNzU3NTMzNw@@._V1_SY1000_CR0,0,735,1000_AL_.jpg" } },
];