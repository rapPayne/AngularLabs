import { Component, OnInit } from '@angular/core';
import { people } from './listOfPeople';
import { Http } from '@angular/http';
import { PeopleService } from './people.service';


@Component({
  selector: 'demo-built-in-directives',
  templateUrl: './built-in-directives.component.html',
  styles: [`
  input.ng-invalid.ng-touched { background-color: orange; color: red;}
  `],
  providers: [ PeopleService ]
})
export class BuiltInDirectivesComponent implements OnInit {
  people = [];
  newPerson = { name: {}, picture: {} };
  constructor(private _http: Http,
     private _peopleService:PeopleService) { }

  ngOnInit() {
    //this.people = people;

    this.getRandomUsersFromAService(12);
    //this.people.forEach(p => console.log(p));
  }

  getRandomUsersFromAService(numberOfUsers) {
    this._peopleService.getRandomPeople(numberOfUsers)
    .subscribe(
      res => this.people = res.json().results,
      err => console.error("Problem with Ajax",err)
    );
  }

  getRandomUsers(numberOfUsers) {
    const url = "https://randomuser.me/api/?results=" + numberOfUsers;
    this._http.get(url)
      .subscribe(
      httpResponse => {
        this.people = httpResponse.json().results;
      },
      error => console.log("Problem", error)
      )
  }

  deletePerson(person) {
    console.log(person);
    this.people = this.people.filter(p => p != person);
  }

  addPerson(newPerson) {
    const p = Object.assign({}, newPerson);
    this.newPerson = { name: {}, picture: {} };
    this.people.unshift(p);
  }
}