import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class PeopleService {

  constructor(private _http:Http) { }

  getRandomPeople(numberOfPeople) {

    const url = "https://randomuser.me/api/?results=" + numberOfPeople;
    return this._http.get(url);

  }

}
