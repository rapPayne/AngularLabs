export const people = [
  {
    "gender": "female",
    "name": { "first": "maëlia", "last": "dupuis" }, 
    "location": { "street": "2553 quai charles-de-gaulle", "city": "perpignan", "state": "saône-et-loire", "postcode": 60947 }, "email": "maëlia.dupuis@example.com",
    "login": { "username": "orangebird335", "password": "satchmo", "salt": "KIzLo90m", "md5": "b68b779525c514ceaefa3ea49f6680c5", "sha1": "81dea869c542d3536a2d197c7f5196485d131233", "sha256": "2718c39f7f96b3a7a3147eb97f4bb8b1a4baf5f47376149a627341d134afeef0" },
    "dob": "1986-01-27 00:37:30",
    "registered": "2010-12-08 16:28:46",
    "phone": "05-41-19-62-03", 
    "cell": "06-76-31-32-56", 
    "id": { "name": "INSEE", "value": "286054377362 95" },
    "picture": { "large": "https://randomuser.me/api/portraits/women/65.jpg", "medium": "https://randomuser.me/api/portraits/med/women/65.jpg", "thumbnail": "https://randomuser.me/api/portraits/thumb/women/65.jpg" }, "nat": "FR"
  },
  {
    "gender": "female",
    "name": { "first": "susanne", "last": "scott" }, 
    "location": { "street": "8033 church lane", "city": "clane", "state": "laois", "postcode": 59135 },
    "email": "susanne.scott@example.com",
    "login": { "username": "blackladybug751", "password": "hottie", "salt": "HLQYcyup", "md5": "44a418415dfe4eb4361faae933e422cb", "sha1": "1ce22f22b68efc7507ec043946a7bef95ffa3341", "sha256": "0da900596c4081d172ed1e5828a52e96a5fec86ab7b28695b715407493167784" },
    "dob": "1967-01-27 20:17:03", 
    "registered": "2014-02-07 01:01:51", 
    "phone": "071-621-9927", 
    "cell": "081-007-7340", 
    "id": { "name": "PPS", "value": "3431248T" },
    "picture": { "large": "https://randomuser.me/api/portraits/women/4.jpg", "medium": "https://randomuser.me/api/portraits/med/women/4.jpg", "thumbnail": "https://randomuser.me/api/portraits/thumb/women/4.jpg" }, "nat": "IE"
  },
  {
    "gender": "male",
    "name": { "first": "babür", "last": "çörekçi" }, 
    "location": { "street": "1537 anafartalar cd", "city": "hakkâri", "state": "kahramanmaraş", "postcode": 89935 }, "email": "babür.çörekçi@example.com",
    "login": { "username": "crazypeacock747", "password": "danielle", "salt": "545QMRhp", "md5": "b5f1312da487f81642baf5dee2d1c8ae", "sha1": "2154b5a8060fdbed11ab7fda5d8bec77a9237008", "sha256": "dc6c9e7261344b1a0db02c962f5f6fc6c4d394d6aa1c33879a52cbc4e5efa7ce" },
    "dob": "1946-12-21 01:23:12",
    "registered": "2013-06-14 21:00:15", 
    "phone": "(375)-487-5923", 
    "cell": "(743)-870-9450", 
    "id": { "name": "", "value": null },
    "picture": { "large": "https://randomuser.me/api/portraits/men/65.jpg", "medium": "https://randomuser.me/api/portraits/med/men/65.jpg", "thumbnail": "https://randomuser.me/api/portraits/thumb/men/65.jpg" }, "nat": "TR"
  }
];