import { PeopleListComponent } from './people/people-list.component';
import { AboutUsComponent } from './about-us/about-us.component'
import { LocationComponent } from './location/location.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { RouterModule } from '@angular/router';

const routes = [
  {path: "people", component: PeopleListComponent},
  {path: "aboutUs", component: AboutUsComponent},
  {path: "location", component: LocationComponent},
  {path: "contactUs", component: ContactUsComponent},
];

export const configuredRouterModule = RouterModule.forRoot(routes);