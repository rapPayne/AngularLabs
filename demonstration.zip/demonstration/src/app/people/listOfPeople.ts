export const people = [
  { name: { first: "Inica", last: "Yang" }, gender: "female", picture: { large: "" } },
  { name: { first: "Billy Joe", last: "McCue" }, gender: "male", picture: { large: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/George_Clooney-4_The_Men_Who_Stare_at_Goats_TIFF09_%28cropped%29.jpg/220px-George_Clooney-4_The_Men_Who_Stare_at_Goats_TIFF09_%28cropped%29.jpg" } },
  { name: { first: "Cory", last: "Wilkie" }, gender: "male", picture: { large: "https://media.licdn.com/dms/image/C5603AQH74ZDLv5mRSw/profile-displayphoto-shrink_800_800/0?e=1529157600&v=beta&t=_aYGy8RVp8OgjplDro7fACdsP0jl9SGrNMywrz9MkiI" } },
  { name: { first: "Saeed", last: "Nikbakht" }, gender: "male", location: { street: "84 Rainey Street", city: "Arlen", state: "TX", postcode: "75043" }, picture: { large: "" } },
  { name: { first: "Seema", last: "Shettar" }, gender: "female", picture: { large: "https://www.biography.com/.image/c_fit%2Ccs_srgb%2Ch_406%2Cq_50%2Cw_620/MTE1ODA0OTcxMzI5MDk1MTgx/beyonce-knowles-39230-3-raw.jpg" } },
];
