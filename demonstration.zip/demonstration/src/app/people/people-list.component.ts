import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { people } from './listOfPeople';

@Component({
  selector: 'app-people-list',
  templateUrl: './people-list.component.html',
  styleUrls: ['./people-list.component.css']
})
export class PeopleListComponent implements OnInit {
  addThem;
  people;
  first;
  last;
  gender;
  image;

  constructor(private _http:HttpClient) { }

  ngOnInit() {
    this.people = people;
    console.log(this.people);
    // Get people from a RESTful url
    const promise = this._http.get(`https://randomuser.me/api/?results=10`)
    .toPromise();
    promise.then(this.success, this.error);
  }

  success = (response) => {
    console.log("Here's the response:", response);
    this.people = response.results;
  }
  error(err) {
    console.error(`Couldn't retrieve users from the server`, err);
  }
  createPerson(evt) {
    const {first, last, gender, image} = this;
    const newPerson = {name:{first, last}, gender, picture:{large:image}};
    this.people.unshift(newPerson);
    evt.target.reset();
  }

  delete(person) {
    this.people = this.people.filter(p => p !== person);
  }

}
