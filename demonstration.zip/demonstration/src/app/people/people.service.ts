import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PeopleService {
  people;
  peopleAreLoaded=false;
  constructor(private _http: HttpClient) { }

  getRandomPeople(numberOfPeople) {
    // Get people from a RESTful url
    return this._http
    .get(`https://randomuser.me/api/?results=${numberOfPeople}`);
  }
}
