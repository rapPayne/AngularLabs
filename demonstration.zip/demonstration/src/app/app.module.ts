import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { NgModule } from '@angular/core';
import { configuredRouterModule} from './app.router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faTrash, faPlus, faEyeSlash } from '@fortawesome/free-solid-svg-icons';

import { AppComponent } from './app.component';
import { PeopleListComponent } from './people/people-list.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { LocationComponent } from './location/location.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { PersonComponent } from './people/person.component';

library.add(faTrash, faPlus, faEyeSlash);

@NgModule({
  declarations: [
    AppComponent,
    PeopleListComponent,
    ContactUsComponent,
    LocationComponent,
    AboutUsComponent,
    PersonComponent,
  ],
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    HttpClientModule, 
    FontAwesomeModule,
    configuredRouterModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
