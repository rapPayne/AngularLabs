import { Component, OnInit, Input , EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.css']
})
export class PersonComponent implements OnInit {
  @Input() person;
  placeHolderImage = "https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Fcdn.pixabay.com%2Fphoto%2F2016%2F08%2F08%2F09%2F17%2Favatar-1577909_640.png&f=1";
  @Output()
  deletePerson = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  delete(person) {
    //console.log(person);
    this.deletePerson.emit(person);
  }
}
