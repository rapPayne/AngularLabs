export const people = [
  { name: { first: "Diana", last: "Alastname" }, gender: "female", picture: { large: "https://www.biography.com/.image/c_fit%2Ccs_srgb%2Ch_406%2Cq_50%2Cw_620/MTE1ODA0OTcxMzI5MDk1MTgx/beyonce-knowles-39230-3-raw.jpg" } },
  { name: { first: "Frances", last: "Barnes" }, gender: "female", picture: { large: "" } },
  { name: { first: "Patrick", last: "Cummins" }, gender: "male", picture: { large: "" } },
  { name: { first: "Marlon", last: "Davis" }, gender: "male", location: { street: "84 Rainey Street", city: "Arlen", state: "TX", postcode: "75043" }, picture: { large: "" } },
  { name: { first: "Tilden", last: "Edison" }, gender: "male", picture: { large: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/George_Clooney-4_The_Men_Who_Stare_at_Goats_TIFF09_%28cropped%29.jpg/220px-George_Clooney-4_The_Men_Who_Stare_at_Goats_TIFF09_%28cropped%29.jpg" } },
];
