import { Component, OnInit } from '@angular/core';
import { people } from './listOfPeople';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-people-list',
  templateUrl: './people-list.component.html',
  styleUrls: ['./people-list.component.css']
})
export class PeopleListComponent implements OnInit {
  people;
  firstName; lastName; city; state; zip;
  seeAddPerson: boolean;

  constructor(private _http: HttpClient) { }

  ngOnInit() {
    this.people = people;
  }
  fetchRandom(numberOfPeople=10) {
    this._http
      .get(`https://randomuser.me/api/?results=${numberOfPeople}`)
      .toPromise()
      .then(
        (res: any) => {
          console.log("The response was ", res.results);
            this.people = [...res.results, ...this.people];
        },
        (error) => console.error(error)
      );
  }
  toggleAddPerson() {
    this.seeAddPerson = !this.seeAddPerson;
  }

  addPerson() {
    console.log("Adding");
    this.people.push({ name: { first: this.firstName, last: this.lastName }, location: { city: this.city, state: this.state, postcode: this.zip }, picture: { large: "" } })
  }

  delete(person) {
    console.log(person);
    this.people = this.people.filter(p => p !== person);
    // let index = this.people.indexOf(person);
    // this.people = [...this.people.slice(0, index), ...this.people.slice(index + 1)]
  }
}
