import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-people',
  templateUrl: './people.component.html',
  styles: [
    `.peopleSection {
    display: flex;
    flex-wrap: wrap;
  }
  .card {
    width:300px; 
    margin:20px;
  }
  `]
})
export class PeopleComponent implements OnInit {
  people: any[] = []; //= response.results;
  personToAdd = {
    name: {first: "", last:""},
    email: "",
    picture: {large:"https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Mastercard_2019_logo.svg/1200px-Mastercard_2019_logo.svg.png"},
  };
  AddPersonSectionVisible:boolean = false;
  //baseUrl = "https://randomuser.me/api/?results=";
  baseUrl = "http://localhost:3000/people";

  constructor(private _httpClient:HttpClient, private _router:Router) {
  }
  ngOnInit() {
    this.getPeople();
  }
  
  getPeople() {
    this._httpClient
    .get(`${this.baseUrl}`)
    .toPromise()
    .then(
      (res:any) => {
        this.people = [...res, ...this.people];
      },
      error => console.error
    );
  }
  
  addPerson(person) {
    this._httpClient.post(this.baseUrl, person)
    .toPromise()
    .then(
      (data) => {
        this.people.unshift(person);
        console.log(data)
      },
      (error) => {console.error(error)}
    );
    this.AddPersonSectionVisible = false;
  }

  deletePerson(person) {
    console.log("deleted ", person)
    this.people = this.people.filter(p => p !== person);
  }

  goToPerson(person) {
    this._router.navigate(["/people", person.id])
  }
}
