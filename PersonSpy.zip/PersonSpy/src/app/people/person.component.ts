import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ɵangular_packages_router_router_a, Router } from '@angular/router';

@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styles: [
    `.peopleSection {
    display: flex;
    flex-wrap: wrap;
  }

  `]
})
export class PersonComponent implements OnInit {

  @Input()
  person;
  @Output() deleted = new EventEmitter();
  baseUrl = "http://localhost:3000/people";
  editing: boolean = false;

  constructor(private _httpClient: HttpClient, private _router:Router) {
  }

  ngOnInit() {
  }

  toggleEdit(event) {
    console.log('clicked')
    event.stopPropagation();
    this.editing=!this.editing
  }
  delete(person, event) {
    event.stopPropagation();
    this.deleted.emit(person);
    this._httpClient
    .delete(`${this.baseUrl}/${person.id}`)
    .toPromise()
    .then(data => { 
      console.log('successfuly deleted', data)
      return data
    })
    .then(people => this._router.navigate(['/people']))
    .catch(console.error)
  }
}
