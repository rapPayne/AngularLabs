import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-add-person',
  templateUrl: './add-person.component.html',
  styles: [`
  .addPersonSection {
    margin: 20px;
  }`,]
})
export class AddPersonComponent implements OnInit {
  @Input()
  person;

  @Output()
  personAdded = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  addPerson(person, event) {
    event.preventDefault();
    this.personAdded.emit(person);
    console.log("In inner")
  }
}
