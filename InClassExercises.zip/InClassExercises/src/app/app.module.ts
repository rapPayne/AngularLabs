import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';

import { routing } from './app.router';
import { AppComponent } from './app.component';
import { PeopleListComponent } from './people/people-list.component';
import { HomeComponent } from './otherThings/home.component';
import { CartComponent } from './otherThings/cart.component';
import { AboutUsComponent } from './otherThings/about-us.component';
import { FourOhFourComponent } from './otherThings/four-oh-four.component';
import { LoginComponent } from './otherThings/login.component';
import { PersonManagerComponent } from './people/person-manager.component';

@NgModule({
  declarations: [
    AppComponent,
    PeopleListComponent,
    HomeComponent,
    CartComponent,
    AboutUsComponent,
    FourOhFourComponent,
    LoginComponent,
    PersonManagerComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    routing,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
