import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-person-manager',
  templateUrl: './person-manager.component.html',
  styleUrls: ['./person-manager.component.css']
})
export class PersonManagerComponent implements OnInit {
  @Input()
  person;
  errorOnPageExists = true;
  @Output()
  deletePerson = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }

  deletePersonManager(person) {
    //console.log('deleting ', person);
    // How do we actually delete them?
    this.deletePerson.emit(person)
  }
}
