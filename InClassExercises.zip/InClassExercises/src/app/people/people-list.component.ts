import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { people as allThePeeps } from '../listOfPeople';

@Component({
  selector: 'app-people-list',
  templateUrl: './people-list.component.html',
  styleUrls: ['./people-list.component.css'],
})
export class PeopleListComponent implements OnInit {
  addingPerson: boolean = true;
  people: Array<any>;
  person = { name: { first: "", last: "" }, email: "", picture: { large: "" } };
  constructor(private _httpClient: HttpClient) { }

  ngOnInit(): void {
    this.getPeople();
    console.log("The people are ", this.people);
  }

  getPeople(numberOfPeople: number = 5) {
    //return allThePeeps;
    const url = `https://randomuser.me/api/?results=${numberOfPeople}`;
    this._httpClient.get(url)
      .subscribe(
        (data:any) => {
          console.log("data is", data);
          this.people = data.results;
        },
        (error) => { console.error("Oh noes!"); }
      );
  }

  addPerson(person, evt) {
    evt.preventDefault();  // Don't submit the form to get a new page
    console.log("You're adding", person);
    this.people.unshift(person);
  }

  toggleAddingPerson() {
    this.addingPerson = !this.addingPerson;
  }

  deletePerson(person) {
    console.log(person);
    this.people = this.people.filter(p => p !== person)
  }
}
