import { RouterModule } from '@angular/router';
import { HomeComponent } from './otherThings/home.component';
import { CartComponent } from './otherThings/cart.component';
import { AboutUsComponent } from './otherThings/about-us.component';
import { FourOhFourComponent } from './otherThings/four-oh-four.component';
import { LoginComponent } from './otherThings/login.component';
import { PeopleListComponent } from './people/people-list.component';

const routes = [
  {path: "home", component: HomeComponent},
  {path: "people", component: PeopleListComponent},
  {path: "cart", component: CartComponent},
  {path: "about", component: AboutUsComponent},
  {path: "login", component: LoginComponent},
  {path: "**", component: FourOhFourComponent },
];

export const routing = RouterModule.forRoot(routes);
