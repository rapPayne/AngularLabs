export const people = [
  { name: { first: "James", last: "Yang" }, gender: "male", picture: { large: "https://images-na.ssl-images-amazon.com/images/M/MV5BMTI4MzIxMTk0Nl5BMl5BanBnXkFtZTcwOTU5NjA0Mg@@._V1_SY1000_CR0,0,666,1000_AL_.jpg" } },
  { name: { first: "Vinita", last: "Kochar" }, gender: "female", picture: { large: "https://media-exp2.licdn.com/media/p/7/000/2a6/383/3840892.jpg" } },
  { name: { first: "Brad", last: "Foxworth-Hill" }, gender: "male", location: {street: {number: 84, name:"Rainey Street"}, city:"Arlen", state: "TX", postcode: "75043" }, picture: { large: "https://images-na.ssl-images-amazon.com/images/M/MV5BMjA1MjE2MTQ2MV5BMl5BanBnXkFtZTcwMjE5MDY0Nw@@._V1_UX214_CR0,0,214,317_AL_.jpg" } },
  { name: { first: "Amit", last: "Tripathi" }, gender: "male", picture: { large: "https://images-na.ssl-images-amazon.com/images/M/MV5BMTM0NzYzNDgxMl5BMl5BanBnXkFtZTcwMDg2MTMyMw@@._V1_.jpg" } },
  { name: { first: "Sowmya", last: "Dandamudi" }, gender: "female", picture: { large: "https://images-na.ssl-images-amazon.com/images/M/MV5BMjEyMTEyOTQ0MV5BMl5BanBnXkFtZTcwNzU3NTMzNw@@._V1_SY1000_CR0,0,735,1000_AL_.jpg" } },
];
