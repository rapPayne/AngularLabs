import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: [
  ]
})
export class LoginComponent implements OnInit {
  _formGroup: FormGroup;
  constructor(private _fb: FormBuilder) { }

  ngOnInit(): void {
    this._formGroup = new FormGroup({
      email: new FormControl("rap@ag.com"),
      password: new FormControl("nunya"),
      submit: new FormControl(),
    });
    this._fb.group({
      email: "rap@creator.net",
      password: "nunya",
    });
  }

}
